<?php return array (
  'profile' => 'App\\Http\\Livewire\\Profile',
  'road-map.epic-form' => 'App\\Http\\Livewire\\RoadMap\\EpicForm',
  'road-map.issue-form' => 'App\\Http\\Livewire\\RoadMap\\IssueForm',
  'ticket.attachments' => 'App\\Http\\Livewire\\Ticket\\Attachments',
  'timesheet.time-logged' => 'App\\Http\\Livewire\\Timesheet\\TimeLogged',
  'validate-account' => 'App\\Http\\Livewire\\ValidateAccount',
);