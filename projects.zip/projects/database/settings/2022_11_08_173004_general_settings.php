<?php

use Spatie\LaravelSettings\Migrations\SettingsMigration;

class GeneralSettings extends SettingsMigration
{
    public function up(): void
    {

    }
}
